#!/bin/bash
# ============================================================
# build-on-vps.sh
# شغّله على الـ VPS مباشرة بعد git clone
# ============================================================

set -e
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
log()  { echo -e "${GREEN}[✓]${NC} $1"; }
info() { echo -e "${YELLOW}[→]${NC} $1"; }

VPS_IP=$(curl -s ifconfig.me)
SITE_PATH="/var/www/restaurant"
REPO_PATH="/root/wb"

echo -e "${CYAN}🔨 بناء الموقع على VPS...${NC}"

# ─── Install Node if needed ────────────────────────────────────
if ! command -v node &>/dev/null; then
  info "تثبيت Node.js..."
  curl -fsSL https://deb.nodesource.com/setup_18.x | bash - > /dev/null
  apt-get install -y nodejs -q
  log "تم تثبيت Node.js $(node -v)"
fi

# ─── Create .env ───────────────────────────────────────────────
info "إنشاء ملف .env..."
read -p "$(echo -e ${YELLOW}"Gemini API Key: "${NC})" GEMINI_KEY
[ -z "$GEMINI_KEY" ] && { echo "Gemini Key مطلوب!"; exit 1; }

cat > ${REPO_PATH}/frontend/.env << ENVEOF
VITE_API_URL=http://${VPS_IP}/api
VITE_GEMINI_KEY=${GEMINI_KEY}
ENVEOF
log "تم إنشاء .env"

# ─── Build Frontend ────────────────────────────────────────────
info "تثبيت packages وبناء الـ Frontend..."
cd ${REPO_PATH}/frontend
npm install --silent 2>&1 | tail -3
npm run build 2>&1 | tail -5
log "تم البناء - $(du -sh dist | cut -f1)"

# ─── Deploy to web root ────────────────────────────────────────
info "نشر الملفات..."
mkdir -p ${SITE_PATH}/api ${SITE_PATH}/uploads

# Copy built frontend
cp -r dist/. ${SITE_PATH}/
log "تم نسخ الـ Frontend"

# Copy PHP API
cp ${REPO_PATH}/php-backend/api/*.php ${SITE_PATH}/api/
cp ${REPO_PATH}/php-backend/index.php ${SITE_PATH}/api/
log "تم نسخ PHP API"

# Set permissions
chown -R www-data:www-data ${SITE_PATH}
chmod -R 755 ${SITE_PATH}
chmod -R 775 ${SITE_PATH}/uploads
log "تم ضبط الصلاحيات"

# ─── Update Nginx config ───────────────────────────────────────
info "تحديث Nginx..."
cat > /etc/nginx/sites-available/restaurant << NGINXEOF
server {
    listen 80;
    server_name ${VPS_IP} _;
    root ${SITE_PATH};
    index index.html;
    client_max_body_size 20M;

    location / {
        try_files \$uri \$uri/ /index.html;
        add_header Cache-Control "no-cache";
    }

    location ~* \.(js|css|png|jpg|jpeg|gif|webp|svg|ico|woff2?)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    location /api/ {
        try_files \$uri \$uri/ /api/index.php?\$query_string;
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME ${SITE_PATH}/api/index.php;
        fastcgi_param REQUEST_URI \$request_uri;
        include fastcgi_params;
        fastcgi_read_timeout 60;
    }

    location /uploads/ {
        alias ${SITE_PATH}/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
        add_header Access-Control-Allow-Origin "*";
    }

    location /webhook/ {
        proxy_pass http://127.0.0.1:4000/;
        proxy_set_header Host \$host;
        proxy_read_timeout 30;
    }

    location ~ /\.(env|git|htaccess) { deny all; }
    location ~ \.(sql|log|sh)$ { deny all; }

    access_log /var/log/nginx/restaurant.access.log;
    error_log  /var/log/nginx/restaurant.error.log;
}
NGINXEOF

ln -sf /etc/nginx/sites-available/restaurant /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
log "تم تحديث Nginx"

# ─── Update PHP config URL ─────────────────────────────────────
info "تحديث config.php..."
sed -i "s|define('APP_URL'.*|define('APP_URL', 'http://${VPS_IP}');|" ${SITE_PATH}/api/../config.php 2>/dev/null || true
sed -i "s|define('UPLOAD_URL'.*|define('UPLOAD_URL', 'http://${VPS_IP}/uploads/');|" /var/www/restaurant/config.php 2>/dev/null || true
log "تم تحديث config.php"

# ─── Done ──────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║     ✅ الموقع جاهز وشغال!           ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"
echo ""
echo -e "🌐 الموقع:    ${GREEN}http://${VPS_IP}${NC}"
echo -e "⚙️  الأدمن:   ${GREEN}http://${VPS_IP}/admin${NC}"
echo -e "🔑 دخول:     admin@restaurant.com / password"
echo ""
echo -e "${YELLOW}⚠️  غيّر كلمة مرور الأدمن من الإعدادات!${NC}"
