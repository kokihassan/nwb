import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore } from '../store'

// ─── Translation hook ─────────────────────────────────────────
export function useT() {
  const lang = useAppStore(s => s.lang)
  return (ar, en) => lang === 'ar' ? ar : en
}

// ─── Spinner ──────────────────────────────────────────────────
export function Spinner({ size = 32, color = '#c9a84c' }) {
  return (
    <div style={{
      width: size, height: size,
      border: `3px solid transparent`,
      borderTop: `3px solid ${color}`,
      borderRadius: '50%',
      animation: 'spin 0.8s linear infinite',
      display: 'inline-block',
    }} />
  )
}

export function PageSpinner() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <div className="text-center space-y-4">
        <Spinner size={48} />
        <p className="text-obsidian-400 text-sm">جاري التحميل...</p>
      </div>
    </div>
  )
}

// ─── Toast ────────────────────────────────────────────────────
export function Toast({ msg, type = 'success', onClose }) {
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20 }}
        className={`fixed top-5 left-1/2 -translate-x-1/2 z-[999] flex items-center gap-3 px-6 py-3 rounded-2xl shadow-2xl text-white font-bold text-sm ${type === 'error' ? 'bg-red-600' : 'bg-emerald-600'}`}
      >
        <span>{type === 'error' ? '✕' : '✓'}</span>
        {msg}
        <button onClick={onClose} className="opacity-60 hover:opacity-100 ml-2">×</button>
      </motion.div>
    </AnimatePresence>
  )
}

// ─── Modal ────────────────────────────────────────────────────
export function Modal({ title, onClose, children, maxW = 'max-w-lg', noPad = false }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className={`bg-obsidian-800 border border-obsidian-700 rounded-2xl ${maxW} w-full max-h-[92vh] overflow-y-auto shadow-2xl`}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-obsidian-700 sticky top-0 bg-obsidian-800 rounded-t-2xl z-10">
          <h3 className="text-lg font-black text-white">{title}</h3>
          <button onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-xl bg-obsidian-700 hover:bg-obsidian-600 text-obsidian-300 transition-colors text-sm">
            ✕
          </button>
        </div>
        <div className={noPad ? '' : 'p-5'}>{children}</div>
      </motion.div>
    </motion.div>
  )
}

// ─── Status Badge ─────────────────────────────────────────────
export function StatusBadge({ status }) {
  const labels = {
    new: 'جديد 🔵', confirmed: 'مؤكد', preparing: 'قيد التحضير 🔥',
    ready: 'جاهز ✨', out_for_delivery: 'في الطريق 🛵',
    delivered: 'تم التسليم ✅', cancelled: 'ملغي ✕',
  }
  return (
    <span className={`status-${status} px-2.5 py-1 rounded-lg text-xs font-bold`}>
      {labels[status] || status}
    </span>
  )
}

// ─── Toggle ───────────────────────────────────────────────────
export function Toggle({ checked, onChange, size = 'md' }) {
  const w = size === 'sm' ? 'w-10 h-5' : 'w-12 h-6'
  const thumb = size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'
  return (
    <button onClick={onChange}
      className={`relative rounded-full transition-colors flex-shrink-0 ${w} ${checked ? 'bg-emerald-500' : 'bg-obsidian-600'}`}>
      <span className={`absolute top-0.5 ${thumb} bg-white rounded-full shadow transition-all ${checked ? 'right-0.5' : 'left-0.5'}`} />
    </button>
  )
}

// ─── Input ────────────────────────────────────────────────────
export function Input({ label, error, ...props }) {
  return (
    <div className="space-y-1.5">
      {label && <label className="block text-xs font-bold text-obsidian-400 uppercase tracking-wide">{label}</label>}
      <input {...props} className={`input-gold ${error ? 'border-red-500' : ''} ${props.className || ''}`} />
      {error && <p className="text-red-400 text-xs">{error}</p>}
    </div>
  )
}

export function Textarea({ label, error, ...props }) {
  return (
    <div className="space-y-1.5">
      {label && <label className="block text-xs font-bold text-obsidian-400 uppercase tracking-wide">{label}</label>}
      <textarea {...props} className={`input-gold resize-none ${error ? 'border-red-500' : ''} ${props.className || ''}`} />
      {error && <p className="text-red-400 text-xs">{error}</p>}
    </div>
  )
}

export function Select({ label, error, children, ...props }) {
  return (
    <div className="space-y-1.5">
      {label && <label className="block text-xs font-bold text-obsidian-400 uppercase tracking-wide">{label}</label>}
      <select {...props} className={`input-gold ${error ? 'border-red-500' : ''} ${props.className || ''}`}>
        {children}
      </select>
      {error && <p className="text-red-400 text-xs">{error}</p>}
    </div>
  )
}

// ─── Card skeleton ────────────────────────────────────────────
export function SkeletonCard() {
  return (
    <div className="card overflow-hidden">
      <div className="skeleton h-44 rounded-none" />
      <div className="p-4 space-y-3">
        <div className="skeleton h-4 w-3/4 rounded" />
        <div className="skeleton h-3 w-full rounded" />
        <div className="skeleton h-3 w-2/3 rounded" />
        <div className="flex justify-between items-center mt-2">
          <div className="skeleton h-5 w-16 rounded" />
          <div className="skeleton h-8 w-24 rounded-lg" />
        </div>
      </div>
    </div>
  )
}

// ─── Empty state ──────────────────────────────────────────────
export function Empty({ icon = '📭', title, desc, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="text-6xl mb-4 anim-float">{icon}</div>
      <h3 className="text-lg font-bold text-obsidian-200 mb-2">{title}</h3>
      {desc && <p className="text-obsidian-400 text-sm mb-6 max-w-xs">{desc}</p>}
      {action}
    </div>
  )
}

// ─── Gold divider ─────────────────────────────────────────────
export function GoldDivider() {
  return (
    <div className="flex items-center gap-4 my-8">
      <div className="flex-1 h-px bg-gradient-to-r from-transparent to-gold-600/40" />
      <span className="text-gold-500 text-xs tracking-[6px]">✦ ✦ ✦</span>
      <div className="flex-1 h-px bg-gradient-to-l from-transparent to-gold-600/40" />
    </div>
  )
}
