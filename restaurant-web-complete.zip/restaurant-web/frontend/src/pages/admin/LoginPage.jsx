import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { adminApi } from '../../api'

export default function LoginPage() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: 'admin@restaurant.com', password: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const login = async () => {
    if (!form.password) return setError('أدخل كلمة المرور')
    setLoading(true); setError('')
    try {
      const res = await adminApi.login(form)
      if (res.success) {
        localStorage.setItem('admin_token', res.data.token)
        localStorage.setItem('admin_user', JSON.stringify(res.data.user))
        navigate('/admin/dashboard')
      } else setError(res.message || 'بيانات خاطئة')
    } catch(e) {
      setError(e.message || 'خطأ في الاتصال')
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-obsidian-950 flex items-center justify-center p-4" dir="rtl">
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-20 h-20 rounded-2xl mx-auto mb-4 flex items-center justify-center text-3xl shadow-2xl rotate-3"
            style={{ background: 'linear-gradient(135deg, #c9a84c, #e8c96d)' }}>🍽️</div>
          <h1 className="text-3xl font-black text-white">لوحة التحكم</h1>
          <p className="text-obsidian-500 text-sm mt-1">نظام إدارة المطعم الذكي</p>
        </div>
        <div className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-7 space-y-5">
          {error && (
            <div className="bg-red-900/30 border border-red-800 text-red-400 rounded-xl p-3 text-sm">⚠️ {error}</div>
          )}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-obsidian-400 uppercase tracking-wide">البريد الإلكتروني</label>
            <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
              className="input-gold" />
          </div>
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-obsidian-400 uppercase tracking-wide">كلمة المرور</label>
            <input type="password" value={form.password}
              onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
              onKeyDown={e => e.key === 'Enter' && login()}
              className="input-gold" placeholder="••••••••" />
          </div>
          <button onClick={login} disabled={loading} className="btn-gold w-full py-3.5 rounded-xl font-bold text-sm">
            {loading ? '⏳ جاري الدخول...' : 'دخول ←'}
          </button>
          <p className="text-center text-xs text-obsidian-600">
            كلمة المرور الافتراضية: <code className="bg-obsidian-700 px-2 py-0.5 rounded font-mono text-obsidian-300">password</code>
          </p>
        </div>
      </motion.div>
    </div>
  )
}
