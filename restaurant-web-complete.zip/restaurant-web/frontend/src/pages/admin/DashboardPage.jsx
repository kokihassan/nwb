export { DashboardPage as default } from './AdminPages'
