import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { useAppStore, useCartStore } from '../../store'
import { publicApi } from '../../api'
import { useT, SkeletonCard, Empty } from '../../components/ui'
import toast from 'react-hot-toast'

export default function MenuPage() {
  const t = useT()
  const navigate = useNavigate()
  const { settings, branches, selectedBranch, setSelectedBranch } = useAppStore()
  const { add, count, total } = useCartStore()
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeCat, setActiveCat] = useState('all')
  const [search, setSearch] = useState('')
  const catRefs = useRef({})

  useEffect(() => {
    setLoading(true)
    publicApi.getMenu(selectedBranch?.id || 1).then(r => {
      if (r.success) setCategories(r.data || [])
      setLoading(false)
    })
  }, [selectedBranch])

  const allItems = categories.flatMap(c => (c.items || []).map(i => ({ ...i, catName: c.name })))
  const filtered = allItems.filter(i =>
    (activeCat === 'all' || i.catName === activeCat) &&
    (!search || i.name.includes(search) || i.name.toLowerCase().includes(search.toLowerCase()))
  )

  const handleAdd = (item) => {
    add({ id: item.id, name: item.name, price: parseFloat(item.final_price || item.price), image: item.image })
    toast.success(t(`✓ ${item.name}`, `✓ ${item.name} added`))
  }

  const scrollToCat = (catName) => {
    setActiveCat(catName)
    catRefs.current[catName]?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <div className="pt-20 min-h-screen">
      {/* ── Header ── */}
      <div className="bg-obsidian-900 border-b border-obsidian-800 sticky top-16 sm:top-20 z-30">
        <div className="max-w-7xl mx-auto px-4 pt-4 pb-0">
          {/* Title + branch + search row */}
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <h1 className="font-display text-2xl font-light italic text-white me-auto">
              {t('قائمة الطعام', 'Our Menu')}
            </h1>
            {/* Branch selector */}
            {branches.length > 1 && (
              <div className="flex gap-2">
                {branches.filter(b => b.is_active).map(b => (
                  <button key={b.id} onClick={() => setSelectedBranch(b)}
                    className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all border ${
                      selectedBranch?.id === b.id
                        ? 'bg-gold-500 text-obsidian-900 border-gold-500'
                        : 'bg-transparent text-obsidian-400 border-obsidian-700 hover:border-gold-600'
                    }`}>
                    📍 {b.name}
                  </button>
                ))}
              </div>
            )}
            {/* Search */}
            <div className="relative w-full sm:w-64">
              <span className="absolute start-3 top-1/2 -translate-y-1/2 text-obsidian-500 text-sm">🔍</span>
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder={t('ابحث...', 'Search...')}
                className="w-full bg-obsidian-800 border border-obsidian-700 rounded-xl ps-9 pe-4 py-2 text-sm text-white placeholder-obsidian-500 outline-none focus:border-gold-600 transition-colors font-inherit" />
            </div>
          </div>

          {/* Category tabs */}
          <div className="flex gap-1 overflow-x-auto pb-0 scrollbar-hide">
            <button onClick={() => { setActiveCat('all'); setSearch('') }}
              className={`flex-shrink-0 px-5 py-3 text-xs font-bold transition-all border-b-2 ${
                activeCat === 'all' ? 'text-gold-400 border-gold-500' : 'text-obsidian-400 border-transparent hover:text-gold-400'
              }`}>
              {t('الكل', 'All')} ({allItems.length})
            </button>
            {categories.map(cat => (
              <button key={cat.id} onClick={() => scrollToCat(cat.name)}
                className={`flex-shrink-0 px-5 py-3 text-xs font-bold transition-all border-b-2 whitespace-nowrap ${
                  activeCat === cat.name ? 'text-gold-400 border-gold-500' : 'text-obsidian-400 border-transparent hover:text-gold-400'
                }`}>
                {cat.icon} {cat.name} ({(cat.items || []).length})
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Content ── */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {Array(8).fill(0).map((_, i) => <SkeletonCard key={i} />)}
          </div>
        ) : search ? (
          // Search results
          filtered.length === 0
            ? <Empty icon="🔍" title={t('لا نتائج', 'No Results')} desc={t('جرّب كلمة بحث تانية', 'Try a different keyword')} />
            : (
              <div>
                <p className="text-obsidian-400 text-sm mb-5">{filtered.length} {t('نتيجة', 'results')}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                  {filtered.map(item => (
                    <MenuItemCard key={item.id} item={item} onAdd={() => handleAdd(item)} t={t} settings={settings} />
                  ))}
                </div>
              </div>
            )
        ) : (
          // Category sections
          <div className="space-y-14">
            {categories.map(cat => (
              <section key={cat.id} ref={el => catRefs.current[cat.name] = el}>
                <div className="flex items-center gap-4 mb-6">
                  <div>
                    <h2 className="text-xl font-black text-white">
                      {cat.icon} {cat.name}
                    </h2>
                    {cat.description && <p className="text-obsidian-500 text-sm mt-0.5">{cat.description}</p>}
                  </div>
                  <div className="flex-1 h-px bg-gradient-to-r from-obsidian-700 to-transparent" />
                  <span className="text-obsidian-600 text-xs">{(cat.items || []).length} {t('صنف', 'items')}</span>
                </div>
                {(cat.items || []).length === 0
                  ? <p className="text-obsidian-600 text-sm py-4">{t('لا توجد أصناف متاحة', 'No items available')}</p>
                  : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                      {(cat.items || []).map(item => (
                        <MenuItemCard key={item.id} item={item} onAdd={() => handleAdd(item)} t={t} settings={settings} />
                      ))}
                    </div>
                  )
                }
              </section>
            ))}
          </div>
        )}
      </div>

      {/* ── Floating cart ── */}
      <AnimatePresence>
        {count > 0 && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-6 start-1/2 -translate-x-1/2 z-40"
          >
            <button onClick={() => navigate('/cart')}
              className="btn-gold flex items-center gap-3 px-8 py-4 rounded-full shadow-2xl text-sm font-bold"
              style={{ boxShadow: '0 8px 32px rgba(201,168,76,0.4)' }}>
              <span className="bg-obsidian-900 text-gold-400 rounded-full w-7 h-7 flex items-center justify-center text-xs font-black">{count}</span>
              {t('عرض السلة', 'View Cart')}
              <span className="font-black">{total} {settings?.currency || t('ج','EGP')}</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function MenuItemCard({ item, onAdd, t, settings }) {
  const [adding, setAdding] = useState(false)
  const { items } = useCartStore()
  const inCart = items.find(i => i.id === item.id)?.qty || 0

  const handleAdd = () => {
    setAdding(true)
    onAdd()
    setTimeout(() => setAdding(false), 700)
  }

  return (
    <motion.div whileHover={{ y: -4 }} transition={{ type: 'spring', stiffness: 300 }}
      className="card overflow-hidden group">
      {/* Image */}
      <div className="relative h-44 overflow-hidden">
        {item.image
          ? <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
          : <div className="w-full h-full bg-gradient-to-br from-obsidian-700 to-obsidian-800 flex items-center justify-center text-5xl">🍽️</div>
        }
        <div className="absolute top-2 start-2 flex gap-1 flex-wrap">
          {item.is_featured === 1 && <span className="badge-gold text-[9px] px-2 py-0.5 rounded-full">⭐ {t('مميز','TOP')}</span>}
          {item.is_new === 1 && <span className="badge-gold badge-new text-[9px] px-2 py-0.5 rounded-full">{t('جديد','NEW')}</span>}
          {item.is_spicy === 1 && <span className="badge-gold badge-spicy text-[9px] px-2 py-0.5 rounded-full">🌶️</span>}
          {item.is_vegetarian === 1 && <span className="bg-green-600 text-white text-[9px] px-2 py-0.5 rounded-full font-bold">🥗</span>}
        </div>
        {inCart > 0 && (
          <div className="absolute top-2 end-2 bg-gold-500 text-obsidian-900 w-6 h-6 rounded-full flex items-center justify-center text-xs font-black">
            {inCart}
          </div>
        )}
        {item.branch_available === 0 && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="bg-red-600 text-white px-3 py-1 rounded text-xs font-bold">{t('غير متاح','N/A')}</span>
          </div>
        )}
      </div>
      {/* Body */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-bold text-white text-sm leading-snug flex-1">{item.name}</h3>
          <span className="gold-text font-black text-base whitespace-nowrap">
            {parseFloat(item.final_price || item.price).toFixed(0)} {settings?.currency || t('ج','EGP')}
          </span>
        </div>
        {item.description && (
          <p className="text-obsidian-500 text-xs leading-relaxed mb-3 truncate-2">{item.description}</p>
        )}
        <div className="flex items-center justify-between">
          <span className="text-obsidian-600 text-xs">⏱️ {item.preparation_time_minutes} {t('د','m')}</span>
          <button onClick={handleAdd} disabled={item.branch_available === 0}
            className={`btn-gold px-4 py-1.5 rounded-lg text-xs font-bold ${item.branch_available === 0 ? 'opacity-40 cursor-not-allowed' : ''}`}>
            {adding ? '✓' : inCart > 0 ? `+ (${inCart})` : t('أضف','Add')}
          </button>
        </div>
      </div>
    </motion.div>
  )
}
