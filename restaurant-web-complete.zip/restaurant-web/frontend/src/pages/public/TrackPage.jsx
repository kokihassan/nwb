import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useT } from '../../components/ui'
import { useAppStore } from '../../store'

const ORDER_STEPS = [
  { key: 'new', icon: '📥', ar: 'تم الاستلام', en: 'Order Received' },
  { key: 'confirmed', icon: '✅', ar: 'تم التأكيد', en: 'Confirmed' },
  { key: 'preparing', icon: '👨‍🍳', ar: 'قيد التحضير', en: 'Preparing' },
  { key: 'ready', icon: '✨', ar: 'جاهز', en: 'Ready' },
  { key: 'out_for_delivery', icon: '🛵', ar: 'في الطريق', en: 'On The Way' },
  { key: 'delivered', icon: '🎉', ar: 'تم التسليم', en: 'Delivered' },
]

export default function TrackPage() {
  const t = useT()
  const navigate = useNavigate()
  const { orderNumber } = useParams()
  const { state } = useLocation()
  const { settings } = useAppStore()
  const order = state?.order
  const status = order?.status || 'new'
  const currentIdx = ORDER_STEPS.findIndex(s => s.key === status)
  const currency = settings?.currency || t('ج', 'EGP')

  return (
    <div className="pt-20 min-h-screen flex items-center justify-center px-4 py-12">
      <div className="max-w-lg w-full">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring' }}
          className="text-center mb-8">
          <div className="text-7xl mb-4 anim-float">🎉</div>
          <h1 className="text-3xl font-black text-white mb-2">{t('تم استلام طلبك!', 'Order Received!')}</h1>
          <div className="gold-text text-2xl font-black">{orderNumber || order?.order_number}</div>
        </motion.div>

        {/* Progress tracker */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-6 mb-5">
          <div className="relative">
            {/* Progress bar */}
            <div className="absolute top-5 start-[8%] end-[8%] h-0.5 bg-obsidian-700" />
            <div className="absolute top-5 start-[8%] h-0.5 bg-gradient-to-r from-gold-500 to-gold-300 transition-all duration-700"
              style={{ width: `${Math.max(0, (currentIdx / (ORDER_STEPS.length - 1)) * 84)}%` }} />

            {/* Steps */}
            <div className="relative flex justify-between">
              {ORDER_STEPS.map((step, i) => (
                <div key={step.key} className="flex flex-col items-center gap-2 flex-1">
                  <motion.div
                    animate={{ scale: i === currentIdx ? [1, 1.2, 1] : 1 }}
                    transition={{ repeat: i === currentIdx ? Infinity : 0, duration: 1.5 }}
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-lg transition-all border-2 z-10
                      ${i < currentIdx ? 'bg-gold-500 border-gold-500 text-obsidian-900'
                        : i === currentIdx ? 'bg-gold-500/20 border-gold-500 text-gold-400'
                        : 'bg-obsidian-700 border-obsidian-600 text-obsidian-500'}`}>
                    {i < currentIdx ? '✓' : step.icon}
                  </motion.div>
                  <span className={`text-[9px] sm:text-xs font-bold text-center leading-tight transition-colors
                    ${i === currentIdx ? 'text-gold-400' : i < currentIdx ? 'text-gold-600' : 'text-obsidian-600'}`}>
                    {t(step.ar, step.en)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Order details */}
        {order && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
            className="bg-obsidian-800 border border-obsidian-700 rounded-2xl p-5 mb-5 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-obsidian-400">{t('إجمالي الطلب', 'Order Total')}</span>
              <span className="gold-text font-black text-xl">{order.total} {currency}</span>
            </div>
            {order.estimated_time && (
              <div className="flex justify-between text-sm">
                <span className="text-obsidian-400">{t('وقت التوصيل المتوقع', 'Est. Delivery')}</span>
                <span className="text-white font-bold">⏱️ {order.estimated_time} {t('دقيقة', 'min')}</span>
              </div>
            )}
            <div className="bg-gold-900/20 border border-gold-800/30 rounded-xl p-3 text-sm text-gold-300 text-center">
              {t('سنبعتلك إشعار لما الطلب يتغير ✅', 'You\'ll be notified when your order status updates ✅')}
            </div>
          </motion.div>
        )}

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}
          className="flex gap-3">
          <button onClick={() => navigate('/')} className="btn-gold flex-1 py-3 rounded-xl text-sm font-bold">
            {t('الرئيسية', 'Home')}
          </button>
          <button onClick={() => navigate('/menu')} className="btn-ghost flex-1 py-3 rounded-xl text-sm font-bold">
            {t('طلب جديد', 'New Order')}
          </button>
        </motion.div>
      </div>
    </div>
  )
}
