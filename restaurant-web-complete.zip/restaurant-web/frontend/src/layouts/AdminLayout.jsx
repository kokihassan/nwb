import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore } from '../store'
import { adminApi } from '../api'

const NAV = [
  { path: '/admin/dashboard', icon: '📊', ar: 'الداشبورد', en: 'Dashboard' },
  { path: '/admin/orders', icon: '📦', ar: 'الطلبات', en: 'Orders' },
  { path: '/admin/menu', icon: '🍽️', ar: 'المنيو', en: 'Menu' },
  { path: '/admin/offers', icon: '🎁', ar: 'الأوفر', en: 'Offers' },
  { path: '/admin/branches', icon: '📍', ar: 'الفروع', en: 'Branches' },
  { path: '/admin/customers', icon: '👥', ar: 'العملاء', en: 'Customers' },
  { path: '/admin/coupons', icon: '🎫', ar: 'الكوبونات', en: 'Coupons' },
  { path: '/admin/reports', icon: '📈', ar: 'التقارير', en: 'Reports' },
  { path: '/admin/settings', icon: '⚙️', ar: 'الإعدادات', en: 'Settings' },
]

export default function AdminLayout() {
  const navigate = useNavigate()
  const location = useLocation()
  const { lang, settings } = useAppStore()
  const isAr = lang === 'ar'
  const t = (ar, en) => isAr ? ar : en
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [newOrders, setNewOrders] = useState(0)
  const [user] = useState(() => { try { return JSON.parse(localStorage.getItem('admin_user')) } catch { return null } })

  const logout = () => {
    localStorage.removeItem('admin_token')
    localStorage.removeItem('admin_user')
    navigate('/admin/login')
  }

  // Poll for new orders
  useEffect(() => {
    const poll = () => {
      adminApi.getStats(new Date().toISOString().split('T')[0]).then(r => {
        if (r.success) setNewOrders(r.data.new_orders_count || 0)
      }).catch(() => {})
    }
    poll()
    const t = setInterval(poll, 15000)
    return () => clearInterval(t)
  }, [])

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-obsidian-900 border-e border-obsidian-800">
      {/* Logo */}
      <div className="p-5 border-b border-obsidian-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gold-gradient flex items-center justify-center text-xl shadow-lg">🍽️</div>
          <div>
            <div className="gold-text font-black text-sm leading-tight">{settings?.name || t('مطعمنا','Restaurant')}</div>
            <div className="text-obsidian-500 text-[10px] mt-0.5">{t('لوحة التحكم','Admin Panel')}</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {NAV.map(item => {
          const active = location.pathname === item.path
          return (
            <button key={item.path}
              onClick={() => { navigate(item.path); setSidebarOpen(false) }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all text-start relative
                ${active
                  ? 'bg-gold-500/10 text-gold-400 border border-gold-500/30'
                  : 'text-obsidian-400 hover:bg-obsidian-800 hover:text-white'}`}>
              <span className="text-base">{item.icon}</span>
              <span>{t(item.ar, item.en)}</span>
              {item.path === '/admin/orders' && newOrders > 0 && (
                <span className="absolute end-3 bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse">
                  {newOrders}
                </span>
              )}
            </button>
          )
        })}
      </nav>

      {/* User + logout */}
      <div className="p-3 border-t border-obsidian-800">
        <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-obsidian-800 mb-2">
          <div className="w-8 h-8 rounded-full bg-gold-500/20 border border-gold-500/30 flex items-center justify-center text-gold-400 text-sm font-black">
            {user?.name?.[0] || 'A'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white text-xs font-bold truncate">{user?.name || 'Admin'}</div>
            <div className="text-obsidian-500 text-[10px] truncate">{user?.email}</div>
          </div>
        </div>
        <button onClick={logout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-obsidian-400 hover:bg-red-900/20 hover:text-red-400 transition-all text-sm">
          🚪 {t('خروج','Logout')}
        </button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen flex" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Desktop sidebar */}
      <div className="hidden lg:block w-60 flex-shrink-0 fixed inset-y-0 start-0 z-30">
        <SidebarContent />
      </div>

      {/* Mobile sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
            <motion.div initial={{ x: isAr ? '100%' : '-100%' }} animate={{ x: 0 }} exit={{ x: isAr ? '100%' : '-100%' }}
              className="fixed inset-y-0 start-0 w-64 z-50 lg:hidden shadow-2xl">
              <SidebarContent />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main */}
      <div className="flex-1 lg:ms-60 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-14 bg-obsidian-900 border-b border-obsidian-800 flex items-center px-4 gap-3 sticky top-0 z-20">
          <button onClick={() => setSidebarOpen(true)}
            className="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg bg-obsidian-800 text-obsidian-400 hover:text-white">
            ☰
          </button>
          <span className="font-bold text-white text-sm">
            {NAV.find(n => n.path === location.pathname)?.[isAr ? 'ar' : 'en'] || 'Admin'}
          </span>
          {newOrders > 0 && (
            <button onClick={() => navigate('/admin/orders')}
              className="flex items-center gap-2 bg-red-900/30 border border-red-800 text-red-400 px-3 py-1 rounded-full text-xs font-bold animate-pulse">
              🔔 {newOrders} {t('طلب جديد','new orders')}
            </button>
          )}
          <div className="ms-auto text-obsidian-500 text-xs">
            {new Date().toLocaleDateString(isAr ? 'ar-EG' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </header>

        {/* Page */}
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto bg-obsidian-950">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
