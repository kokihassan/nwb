import axios from 'axios'

// ─── Base URL ─────────────────────────────────────────────────
export const BASE_URL = import.meta.env.VITE_API_URL || '/api'
export const GEMINI_KEY = import.meta.env.VITE_GEMINI_KEY || ''

// ─── Axios Instance ───────────────────────────────────────────
export const http = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
})

// ─── Auth interceptor ─────────────────────────────────────────
http.interceptors.request.use(config => {
  const token = localStorage.getItem('admin_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// ─── Response interceptor ─────────────────────────────────────
http.interceptors.response.use(
  res => res.data,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('admin_token')
      if (window.location.pathname.startsWith('/admin')) {
        window.location.href = '/admin/login'
      }
    }
    return Promise.reject(err.response?.data || { message: 'Network error' })
  }
)

// ─── Public API ───────────────────────────────────────────────
export const publicApi = {
  getMenu:     (branchId) => http.get(`menu/public?branch_id=${branchId || 1}`),
  getBotMenu:  (branchId) => http.get(`menu/bot-menu?branch_id=${branchId || 1}`),
  getBranches: ()          => http.get('branches/list'),
  getSettings: ()          => http.get('settings/get'),
  getOffers:   ()          => http.get('offers/active'),
  getFaq:      ()          => http.get('settings/faq'),
  findZone:    (area)      => http.get(`branches/find-zone?area=${area}`),
  validateCoupon: (data)   => http.post('coupons/validate', data),
  createOrder: (data)      => http.post('orders/create', data),
  rateOrder:   (data)      => http.post('orders/rate', data),
  getOrCreateCustomer: (wa) => http.post('customers/get-or-create', { whatsapp_number: wa }),
  updateCustomer: (data)   => http.put('customers/update', data),
  addAddress:  (data)      => http.post('customers/add-address', data),
}

// ─── Admin API ────────────────────────────────────────────────
export const adminApi = {
  login:         (data)      => http.post('auth/login', data),
  getStats:      (date)      => http.get(`orders/stats?date=${date}`),
  getOrders:     (params)    => http.get(`orders/list?${new URLSearchParams(params)}`),
  updateOrder:   (id, data)  => http.put(`orders/status/${id}`, data),
  getMenuItems:  (params)    => http.get(`menu/items?${new URLSearchParams(params)}`),
  getCategories: ()          => http.get('menu/categories'),
  createItem:    (data)      => http.post('menu/items', data),
  updateItem:    (id, data)  => http.put(`menu/items/${id}`, data),
  uploadImage:   (id, file)  => {
    const fd = new FormData(); fd.append('image', file)
    return http.post(`menu/upload-image/${id}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  importExcel:   (file) => {
    const fd = new FormData(); fd.append('file', file)
    return http.post('menu/import-excel', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  toggleBranchAvail: (data)  => http.put('menu/branch-availability', data),
  getBranches:   ()          => http.get('branches/list'),
  createBranch:  (data)      => http.post('branches/create', data),
  updateBranch:  (id, data)  => http.put(`branches/update/${id}`, data),
  toggleBranch:  (id)        => http.put(`branches/toggle/${id}`),
  createZone:    (data)      => http.post('branches/zones', data),
  updateZone:    (id, data)  => http.put(`branches/zones/${id}`, data),
  deleteZone:    (id)        => http.delete(`branches/zones/${id}`),
  saveHours:     (data)      => http.post('branches/working-hours', data),
  getCustomers:  (search)    => http.get(`customers/list${search ? `?search=${search}` : ''}`),
  blacklistCustomer: (id, data) => http.put(`customers/blacklist/${id}`, data),
  getCoupons:    ()          => http.get('coupons/list'),
  createCoupon:  (data)      => http.post('coupons/create', data),
  toggleCoupon:  (id)        => http.put(`coupons/toggle/${id}`),
  deleteCoupon:  (id)        => http.delete(`coupons/delete/${id}`),
  getOffers:     ()          => http.get('offers/list'),
  createOffer:   (data)      => http.post('offers/create', data),
  updateOffer:   (id, data)  => http.put(`offers/update/${id}`, data),
  toggleOffer:   (id)        => http.put(`offers/toggle/${id}`),
  deleteOffer:   (id)        => http.delete(`offers/delete/${id}`),
  getSettings:   ()          => http.get('settings/get'),
  updateSettings: (data)     => http.put('settings/update', data),
  toggleOpen:    ()          => http.put('settings/toggle-open'),
  toggleOrders:  ()          => http.put('settings/toggle-orders'),
  getFaq:        ()          => http.get('settings/faq'),
  addFaq:        (data)      => http.post('settings/faq', data),
  deleteFaq:     (id)        => http.delete(`settings/faq/${id}`),
  getReports:    (params)    => http.get(`reports/sales?${new URLSearchParams(params)}`),
  getRatings:    ()          => http.get('reports/ratings'),
  exportCsv:     (params)    => `${BASE_URL}/reports/export-csv?${new URLSearchParams(params)}&token=${localStorage.getItem('admin_token')}`,
}

// ─── Gemini AI ────────────────────────────────────────────────
export async function askGemini(messages, systemPrompt) {
  if (!GEMINI_KEY) return 'يرجى إعداد Gemini API Key'
  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            { role: 'user', parts: [{ text: `[SYSTEM]\n${systemPrompt}` }] },
            { role: 'model', parts: [{ text: 'مفهوم! أنا جاهز أساعد. 😊' }] },
            ...messages.map(m => ({
              role: m.role === 'user' ? 'user' : 'model',
              parts: [{ text: m.content }],
            })),
          ],
          generationConfig: { temperature: 0.8, maxOutputTokens: 600 },
          safetySettings: [
            { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
            { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
          ],
        }),
      }
    )
    const d = await res.json()
    return d.candidates?.[0]?.content?.parts?.[0]?.text || 'عذراً، حاول مرة تانية.'
  } catch {
    return 'عذراً، حدث خطأ مؤقت.'
  }
}
