import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// ─── App Store ────────────────────────────────────────────────
export const useAppStore = create(
  persist(
    (set, get) => ({
      // Theme
      isDark: true,
      lang: 'ar',
      toggleTheme: () => {
        const next = !get().isDark
        set({ isDark: next })
        document.body.className = next ? 'dark' : 'light'
      },
      toggleLang: () => set(s => ({ lang: s.lang === 'ar' ? 'en' : 'ar' })),

      // Settings cache
      settings: null,
      branches: [],
      setSettings: (s) => set({ settings: s }),
      setBranches: (b) => set({ branches: b }),

      // Selected branch
      selectedBranch: null,
      setSelectedBranch: (b) => set({ selectedBranch: b }),

      // Customer
      customer: null,
      setCustomer: (c) => set({ customer: c }),
    }),
    {
      name: 'restaurant-app',
      partialize: (s) => ({ isDark: s.isDark, lang: s.lang, customer: s.customer }),
    }
  )
)

// ─── Cart Store ───────────────────────────────────────────────
export const useCartStore = create(
  persist(
    (set, get) => ({
      items: [],
      coupon: null,
      discount: 0,

      add: (item) => {
        const items = get().items
        const ex = items.find(i => i.id === item.id)
        if (ex) {
          set({ items: items.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i) })
        } else {
          set({ items: [...items, { ...item, qty: 1 }] })
        }
      },

      remove: (id) => set(s => ({ items: s.items.filter(i => i.id !== id) })),

      setQty: (id, qty) => {
        if (qty <= 0) return get().remove(id)
        set(s => ({ items: s.items.map(i => i.id === id ? { ...i, qty } : i) }))
      },

      clear: () => set({ items: [], coupon: null, discount: 0 }),

      setCoupon: (code, discount) => set({ coupon: code, discount }),

      get total() {
        return get().items.reduce((s, i) => s + i.price * i.qty, 0)
      },
      get count() {
        return get().items.reduce((s, i) => s + i.qty, 0)
      },
    }),
    {
      name: 'restaurant-cart',
      partialize: (s) => ({ items: s.items }),
    }
  )
)
