#!/bin/bash
# ============================================================
# deploy.sh - بناء ورفع الموقع على VPS
# شغّله من جهازك: bash deploy.sh
# ============================================================

set -e

VPS_IP="13.62.37.86"
VPS_USER="root"
SITE_PATH="/var/www/restaurant"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
log() { echo -e "${GREEN}[✓]${NC} $1"; }
info() { echo -e "${YELLOW}[→]${NC} $1"; }

echo -e "${GREEN}🚀 بناء ورفع الموقع...${NC}"

# ─── 1. Copy .env ─────────────────────────────────────────────
if [ ! -f frontend/.env ]; then
  cp frontend/.env.example frontend/.env
  echo ""
  echo -e "${YELLOW}⚠️  عدّل frontend/.env الأول:${NC}"
  echo "   VITE_API_URL=http://${VPS_IP}/api"
  echo "   VITE_GEMINI_KEY=YOUR_KEY"
  echo ""
  read -p "هل عدّلت الـ .env؟ (y/n): " ok
  [ "$ok" != "y" ] && exit 1
fi

# ─── 2. Build ─────────────────────────────────────────────────
info "بناء الـ Frontend..."
cd frontend
npm install --silent
npm run build
cd ..
log "تم البناء - $(du -sh frontend/dist | cut -f1)"

# ─── 3. Upload to VPS ─────────────────────────────────────────
info "رفع الملفات على VPS..."

# Upload built frontend
rsync -az --delete frontend/dist/ ${VPS_USER}@${VPS_IP}:${SITE_PATH}/

# Upload PHP API files
rsync -az /root/wb/php-backend/api/ ${VPS_USER}@${VPS_IP}:${SITE_PATH}/api/
rsync -az /root/wb/php-backend/index.php ${VPS_USER}@${VPS_IP}:${SITE_PATH}/api/

# Upload Nginx config
scp nginx/restaurant.conf ${VPS_USER}@${VPS_IP}:/etc/nginx/sites-available/restaurant

# ─── 4. Reload on VPS ─────────────────────────────────────────
info "إعادة تشغيل الخدمات..."
ssh ${VPS_USER}@${VPS_IP} "
  nginx -t && systemctl reload nginx
  echo '✅ Nginx reloaded'
"

log "تم الرفع بنجاح!"
echo ""
echo "🌐 الموقع: http://${VPS_IP}"
echo "⚙️  الأدمن: http://${VPS_IP}/admin"
echo "🔑 دخول: admin@restaurant.com / password"
