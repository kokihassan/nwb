#!/bin/bash
# ============================================================
# build-on-vps.sh
# تثبيت كامل: Frontend (React) + Backend (PHP) + MySQL + Nginx
# بدون واتساب / بدون WAHA
#
# الاستخدام:
#   cd ~/wb
#   sudo bash build-on-vps.sh
# ============================================================

set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[✓]${NC} $1"; }
info() { echo -e "${YELLOW}[→]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; exit 1; }

[ "$EUID" -ne 0 ] && err "شغّل بـ: sudo bash build-on-vps.sh"

# ─── Paths ──────────────────────────────────────────────────
REPO_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SITE_PATH="/var/www/restaurant"
VPS_IP=$(curl -s ifconfig.me || curl -s ipinfo.io/ip)
RUN_USER="${SUDO_USER:-ubuntu}"

echo -e "${CYAN}"
echo "╔══════════════════════════════════════════╗"
echo "║   🍽️  Restaurant Web - Full Installer    ║"
echo "║   Repo: ${REPO_PATH}"
echo "║   Site: ${SITE_PATH}"
echo "║   IP:   ${VPS_IP}"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

# ════════════════════════════════════════════════════════════
# STEP 0: Cleanup old installation (no WAHA, fresh start)
# ════════════════════════════════════════════════════════════
info "تنظيف أي تثبيت قديم..."
docker stop waha 2>/dev/null || true
docker rm waha 2>/dev/null || true
pm2 delete all 2>/dev/null || true
pm2 save --force 2>/dev/null || true
rm -rf "$SITE_PATH"
rm -f /etc/nginx/sites-enabled/restaurant /etc/nginx/sites-available/restaurant
log "تم التنظيف"

# ════════════════════════════════════════════════════════════
# STEP 1: System packages
# ════════════════════════════════════════════════════════════
info "تحديث النظام وتثبيت الحزم..."
apt-get update -qq
apt-get install -y -qq curl wget git unzip software-properties-common ufw

# Nginx
if ! command -v nginx &>/dev/null; then
  apt-get install -y -qq nginx
fi
systemctl enable nginx >/dev/null 2>&1

# PHP 8.1
if ! command -v php &>/dev/null; then
  add-apt-repository -y ppa:ondrej/php >/dev/null 2>&1
  apt-get update -qq
  apt-get install -y -qq php8.1-fpm php8.1-mysql php8.1-curl php8.1-mbstring php8.1-xml php8.1-zip php8.1-gd php8.1-intl php8.1-bcmath
fi
systemctl enable php8.1-fpm >/dev/null 2>&1
systemctl start php8.1-fpm

# MySQL
if ! command -v mysql &>/dev/null; then
  apt-get install -y -qq mysql-server
fi
systemctl enable mysql >/dev/null 2>&1
systemctl start mysql

# Node.js 18
if ! command -v node &>/dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_18.x | bash - >/dev/null 2>&1
  apt-get install -y -qq nodejs
fi
log "Node $(node -v) | PHP $(php -v | head -1 | awk '{print $2}') | $(mysql --version | awk '{print $3}')"

# ════════════════════════════════════════════════════════════
# STEP 2: Collect config
# ════════════════════════════════════════════════════════════
echo ""
echo -e "${CYAN}══════════ إعداد المشروع ══════════${NC}"
read -p "$(echo -e ${YELLOW}"اسم المطعم: "${NC})" RESTAURANT_NAME
RESTAURANT_NAME=${RESTAURANT_NAME:-"مطعمي"}

read -p "$(echo -e ${YELLOW}"Gemini API Key (من aistudio.google.com): "${NC})" GEMINI_KEY
[ -z "$GEMINI_KEY" ] && err "Gemini API Key مطلوب"

read -p "$(echo -e ${YELLOW}"كلمة مرور MySQL (لمستخدم botuser): "${NC})" MYSQL_PASS
MYSQL_PASS=${MYSQL_PASS:-"RestBot$(date +%s)!"}

read -p "$(echo -e ${YELLOW}"كلمة مرور لوحة التحكم (Admin): "${NC})" ADMIN_PASS
ADMIN_PASS=${ADMIN_PASS:-"admin123"}

JWT_SECRET=$(openssl rand -hex 32)
echo ""
log "الإعدادات جاهزة"

# ════════════════════════════════════════════════════════════
# STEP 3: MySQL database
# ════════════════════════════════════════════════════════════
info "إعداد قاعدة البيانات..."
mysql -u root -e "DROP DATABASE IF EXISTS restaurant_bot;" 2>/dev/null || true
mysql -u root -e "DROP USER IF EXISTS 'botuser'@'localhost';" 2>/dev/null || true
mysql -u root << MYSQLEOF
CREATE DATABASE restaurant_bot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'botuser'@'localhost' IDENTIFIED BY '${MYSQL_PASS}';
GRANT ALL PRIVILEGES ON restaurant_bot.* TO 'botuser'@'localhost';
FLUSH PRIVILEGES;
MYSQLEOF
log "تم إنشاء قاعدة البيانات restaurant_bot"

# ════════════════════════════════════════════════════════════
# STEP 4: Import schema
# ════════════════════════════════════════════════════════════
info "استيراد الجداول..."
SCHEMA_FILE="${REPO_PATH}/database/schema.sql"
if [ -f "$SCHEMA_FILE" ]; then
  mysql -u botuser -p"${MYSQL_PASS}" restaurant_bot < "$SCHEMA_FILE"
  log "تم استيراد schema.sql"
else
  err "ملف database/schema.sql غير موجود في ${REPO_PATH}"
fi

# Default settings + admin user (override schema.sql defaults with user's choices)
ADMIN_HASH=$(php -r "echo password_hash('${ADMIN_PASS}', PASSWORD_DEFAULT);")
mysql -u botuser -p"${MYSQL_PASS}" restaurant_bot << SQLEOF
UPDATE restaurant_settings SET
  name='${RESTAURANT_NAME}',
  bot_name='نور',
  welcome_message='أهلاً وسهلاً! 🌟 أنا نور، مساعدتك في ${RESTAURANT_NAME}. كيف أقدر أساعدك؟',
  bot_personality='أنت مساعد ذكي ودود اسمك نور. تتكلم بالعربي بأسلوب ودي ومحترم. تساعد العملاء في معرفة المنيو والطلب وتقترح أصناف بناء على رغبتهم.',
  closed_message='المطعم مغلق حالياً 🌙'
WHERE id = (SELECT id FROM (SELECT id FROM restaurant_settings LIMIT 1) x);

UPDATE admin_users SET password='${ADMIN_HASH}' WHERE email='admin@restaurant.com';
SQLEOF
log "تم ضبط بيانات المطعم وكلمة مرور الأدمن"

# ════════════════════════════════════════════════════════════
# STEP 5: Create site directory structure
# ════════════════════════════════════════════════════════════
info "إنشاء هيكل المجلدات..."
mkdir -p ${SITE_PATH}/api
mkdir -p ${SITE_PATH}/uploads/{items,categories,offers,settings}
mkdir -p ${SITE_PATH}/logs
log "تم إنشاء ${SITE_PATH}"

# ════════════════════════════════════════════════════════════
# STEP 6: PHP config.php
# ════════════════════════════════════════════════════════════
info "إنشاء config.php..."
cat > ${SITE_PATH}/config.php << PHPEOF
<?php
// ============================================================
// DATABASE
// ============================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'restaurant_bot');
define('DB_USER', 'botuser');
define('DB_PASS', '${MYSQL_PASS}');
define('DB_CHARSET', 'utf8mb4');

// ============================================================
// AI / KEYS
// ============================================================
define('GEMINI_API_KEY', '${GEMINI_KEY}');

// ============================================================
// APP
// ============================================================
define('APP_URL', 'http://${VPS_IP}');
define('UPLOAD_PATH', '${SITE_PATH}/uploads/');
define('UPLOAD_URL', 'http://${VPS_IP}/uploads/');
define('JWT_SECRET', '${JWT_SECRET}');
define('ADMIN_SESSION_LIFETIME', 86400);

// ============================================================
// CORS
// ============================================================
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
if (\$_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }

// ============================================================
// DATABASE CONNECTION
// ============================================================
function getDB() {
    static \$pdo = null;
    if (\$pdo === null) {
        try {
            \$dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
            \$pdo = new PDO(\$dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException \$e) {
            http_response_code(500);
            die(json_encode(['error' => 'DB connection failed: ' . \$e->getMessage()]));
        }
    }
    return \$pdo;
}

// ============================================================
// RESPONSES
// ============================================================
function success(\$data = [], \$message = 'success', \$code = 200) {
    http_response_code(\$code);
    echo json_encode(['success' => true, 'message' => \$message, 'data' => \$data], JSON_UNESCAPED_UNICODE);
    exit();
}
function error(\$message = 'Error', \$code = 400, \$data = []) {
    http_response_code(\$code);
    echo json_encode(['success' => false, 'message' => \$message, 'data' => \$data], JSON_UNESCAPED_UNICODE);
    exit();
}

// ============================================================
// JWT AUTH
// ============================================================
function generateToken(\$payload) {
    \$h = rtrim(base64_encode(json_encode(['alg'=>'HS256','typ'=>'JWT'])), '=');
    \$payload['iat'] = time(); \$payload['exp'] = time() + ADMIN_SESSION_LIFETIME;
    \$p = rtrim(base64_encode(json_encode(\$payload)), '=');
    \$s = rtrim(base64_encode(hash_hmac('sha256', "\$h.\$p", JWT_SECRET, true)), '=');
    return "\$h.\$p.\$s";
}
function verifyToken(\$token) {
    \$parts = explode('.', \$token);
    if (count(\$parts) !== 3) return false;
    [\$h, \$p, \$s] = \$parts;
    \$expected = rtrim(base64_encode(hash_hmac('sha256', "\$h.\$p", JWT_SECRET, true)), '=');
    if (!hash_equals(\$s, \$expected)) return false;
    \$data = json_decode(base64_decode(\$p . str_repeat('=', 4 - strlen(\$p) % 4)), true);
    if (!\$data || \$data['exp'] < time()) return false;
    return \$data;
}
function requireAuth() {
    \$headers = getallheaders();
    \$auth = \$headers['Authorization'] ?? \$headers['authorization'] ?? '';
    \$token = null;
    if (str_starts_with(\$auth, 'Bearer ')) {
        \$token = substr(\$auth, 7);
    } elseif (!empty(\$_GET['token'])) {
        // Allow token via query string for direct-download links (export CSV, etc.)
        \$token = \$_GET['token'];
    }
    if (!\$token) error('Unauthorized', 401);
    \$data = verifyToken(\$token);
    if (!\$data) error('Invalid or expired token', 401);
    return \$data;
}

// ============================================================
// FILE UPLOAD
// ============================================================
function uploadImage(\$file, \$folder = 'items') {
    \$uploadDir = UPLOAD_PATH . \$folder . '/';
    if (!is_dir(\$uploadDir)) mkdir(\$uploadDir, 0775, true);
    \$allowed = ['jpg','jpeg','png','webp','gif'];
    \$ext = strtolower(pathinfo(\$file['name'], PATHINFO_EXTENSION));
    if (!in_array(\$ext, \$allowed) || \$file['size'] > 5*1024*1024) return false;
    \$filename = uniqid() . '_' . time() . '.' . \$ext;
    if (move_uploaded_file(\$file['tmp_name'], \$uploadDir . \$filename)) {
        return UPLOAD_URL . \$folder . '/' . \$filename;
    }
    return false;
}

// ============================================================
// ORDER NUMBER
// ============================================================
function generateOrderNumber() {
    \$db = getDB();
    \$stmt = \$db->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()");
    \$count = \$stmt->fetchColumn() + 1;
    return 'ORD-' . date('Ymd') . '-' . str_pad(\$count, 4, '0', STR_PAD_LEFT);
}

// ============================================================
// WHATSAPP NOTIFICATIONS - DISABLED (no WAHA on this server)
// Keeps the API working; notifications are only logged to DB
// and can be viewed/sent manually or wired to another provider.
// ============================================================
function sendWhatsApp(\$number, \$message, \$imageUrl = null) {
    return ['success' => false, 'disabled' => true];
}
PHPEOF
log "تم إنشاء config.php"

# ════════════════════════════════════════════════════════════
# STEP 7: Copy PHP API files (skip webhook.php - no WhatsApp)
# ════════════════════════════════════════════════════════════
info "نسخ ملفات PHP API..."
API_SRC="${REPO_PATH}/php-backend/api"
[ -d "$API_SRC" ] || err "مجلد php-backend/api غير موجود"

for f in "$API_SRC"/*.php; do
  fname=$(basename "$f")
  [ "$fname" = "webhook.php" ] && continue
  cp "$f" ${SITE_PATH}/api/
done
log "تم نسخ ملفات الـ API"

# ─── index.php router (no webhook route) ───────────────────────
cat > ${SITE_PATH}/api/index.php << 'ROUTEREOF'
<?php
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = preg_replace('#^/api/?#', '', $uri);
$uri = trim($uri, '/');
$parts = explode('/', $uri);
$resource = $parts[0] ?? '';
$action   = implode('/', array_slice($parts, 1));
$_GET['action'] = $action;

switch ($resource) {
    case 'menu':      require __DIR__.'/menu.php';      break;
    case 'orders':    require __DIR__.'/orders.php';    break;
    case 'branches':  require __DIR__.'/branches.php';  break;
    case 'customers': require __DIR__.'/customers.php'; break;
    case 'coupons':   require __DIR__.'/coupons.php';   break;
    case 'settings':  require __DIR__.'/settings.php';  break;
    case 'auth':      require __DIR__.'/auth.php';      break;
    case 'offers':    require __DIR__.'/offers.php';    break;
    case 'reports':   require __DIR__.'/reports.php';   break;
    case 'health':
        header('Content-Type: application/json');
        echo json_encode(['status'=>'ok','time'=>date('Y-m-d H:i:s')]);
        break;
    default:
        http_response_code(404);
        echo json_encode(['error'=>'Not found','uri'=>$uri]);
}
ROUTEREOF
log "تم إنشاء api/index.php (router)"

# ════════════════════════════════════════════════════════════
# STEP 8: Build Frontend
# ════════════════════════════════════════════════════════════
info "إعداد ملف .env للـ Frontend..."
cat > ${REPO_PATH}/frontend/.env << ENVEOF
VITE_API_URL=http://${VPS_IP}/api
VITE_GEMINI_KEY=${GEMINI_KEY}
ENVEOF
log "تم إنشاء frontend/.env"

info "تثبيت npm packages (قد يستغرق دقيقة)..."
cd ${REPO_PATH}/frontend
sudo -u "${RUN_USER}" npm install --silent 2>&1 | tail -3

info "بناء الموقع..."
sudo -u "${RUN_USER}" npm run build 2>&1 | tail -8
[ -d dist ] || err "فشل البناء - مجلد dist غير موجود"
log "تم البناء - $(du -sh dist | cut -f1)"

# Copy build output to site root
cp -r dist/. ${SITE_PATH}/
log "تم نشر الـ Frontend"

# ════════════════════════════════════════════════════════════
# STEP 9: Permissions
# ════════════════════════════════════════════════════════════
info "ضبط الصلاحيات..."
chown -R www-data:www-data ${SITE_PATH}
find ${SITE_PATH} -type d -exec chmod 755 {} \;
find ${SITE_PATH} -type f -exec chmod 644 {} \;
chmod -R 775 ${SITE_PATH}/uploads
chmod -R 775 ${SITE_PATH}/logs
# Allow ubuntu user to deploy/update later without sudo on uploads/logs
usermod -a -G www-data "${RUN_USER}" 2>/dev/null || true
log "تم ضبط الصلاحيات (www-data + ${RUN_USER} في نفس المجموعة)"

# ════════════════════════════════════════════════════════════
# STEP 10: Nginx config
# ════════════════════════════════════════════════════════════
info "إعداد Nginx..."
cat > /etc/nginx/sites-available/restaurant << NGINXEOF
server {
    listen 80;
    server_name ${VPS_IP} _;
    root ${SITE_PATH};
    index index.html;
    client_max_body_size 20M;

    # React SPA
    location / {
        try_files \$uri \$uri/ /index.html;
        add_header Cache-Control "no-cache, no-store, must-revalidate";
    }

    # Static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|webp|svg|ico|woff2?)\$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files \$uri =404;
    }

    # PHP API
    location /api/ {
        try_files \$uri \$uri/ /api/index.php?\$query_string;
        fastcgi_split_path_info ^(.+\.php)(/.+)\$;
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME ${SITE_PATH}/api/index.php;
        fastcgi_param REQUEST_URI \$request_uri;
        include fastcgi_params;
        fastcgi_read_timeout 60;
        fastcgi_buffers 16 16k;
        fastcgi_buffer_size 32k;
    }

    # Uploads
    location /uploads/ {
        alias ${SITE_PATH}/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
        add_header Access-Control-Allow-Origin "*";
    }

    # Security
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";

    location ~ /\.(env|git|htaccess) { deny all; return 404; }
    location ~ \.(sql|log|sh)\$ { deny all; return 404; }

    access_log /var/log/nginx/restaurant.access.log;
    error_log  /var/log/nginx/restaurant.error.log;
}
NGINXEOF

ln -sf /etc/nginx/sites-available/restaurant /etc/nginx/sites-enabled/restaurant
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
log "تم إعداد Nginx"

# ════════════════════════════════════════════════════════════
# STEP 11: Firewall
# ════════════════════════════════════════════════════════════
info "إعداد الـ Firewall..."
ufw allow ssh >/dev/null 2>&1 || true
ufw allow 80/tcp >/dev/null 2>&1 || true
ufw allow 443/tcp >/dev/null 2>&1 || true
ufw --force enable >/dev/null 2>&1 || true
log "تم فتح SSH/HTTP/HTTPS"

# ════════════════════════════════════════════════════════════
# STEP 12: Daily backup cron
# ════════════════════════════════════════════════════════════
info "إعداد النسخ الاحتياطي اليومي..."
mkdir -p /var/backups/restaurant
cat > /usr/local/bin/restaurant-backup.sh << BACKUPEOF
#!/bin/bash
DATE=\$(date +%Y%m%d_%H%M)
mkdir -p /var/backups/restaurant
mysqldump -u botuser -p'${MYSQL_PASS}' restaurant_bot | gzip > /var/backups/restaurant/db_\$DATE.sql.gz
find /var/backups/restaurant -name "db_*.sql.gz" -mtime +7 -delete
BACKUPEOF
chmod +x /usr/local/bin/restaurant-backup.sh
( crontab -l 2>/dev/null | grep -v restaurant-backup ; echo "0 3 * * * /usr/local/bin/restaurant-backup.sh" ) | crontab -
log "تم إعداد نسخة احتياطية يومية الساعة 3 صباحاً"

# ════════════════════════════════════════════════════════════
# STEP 13: Management helper
# ════════════════════════════════════════════════════════════
cat > /usr/local/bin/restaurant << 'MGMTEOF'
#!/bin/bash
SITE=/var/www/restaurant
case "$1" in
  status)
    systemctl is-active --quiet nginx && echo "✅ Nginx: running" || echo "❌ Nginx: stopped"
    systemctl is-active --quiet php8.1-fpm && echo "✅ PHP-FPM: running" || echo "❌ PHP-FPM: stopped"
    systemctl is-active --quiet mysql && echo "✅ MySQL: running" || echo "❌ MySQL: stopped"
    curl -s http://localhost/api/health || echo "❌ API not responding"
    ;;
  restart)
    systemctl restart nginx php8.1-fpm mysql
    echo "✅ All services restarted"
    ;;
  logs)
    case "$2" in
      nginx) tail -50 /var/log/nginx/restaurant.error.log ;;
      php)   tail -50 /var/log/php8.1-fpm.log ;;
      *)     tail -50 /var/log/nginx/restaurant.access.log ;;
    esac
    ;;
  rebuild)
    cd ~/wb/frontend && npm run build && cp -r dist/. $SITE/ && chown -R www-data:www-data $SITE
    echo "✅ Frontend rebuilt and deployed"
    ;;
  backup) /usr/local/bin/restaurant-backup.sh && echo "✅ Backup done" ;;
  domain)
    if [ -z "$2" ]; then echo "Usage: restaurant domain yourdomain.com"; exit 1; fi
    DOMAIN=$2
    sed -i "s/server_name .*/server_name $DOMAIN;/" /etc/nginx/sites-available/restaurant
    sed -i "s|define('APP_URL'.*|define('APP_URL', 'https://$DOMAIN');|" $SITE/config.php
    sed -i "s|define('UPLOAD_URL'.*|define('UPLOAD_URL', 'https://$DOMAIN/uploads/');|" $SITE/config.php
    nginx -t && systemctl reload nginx
    apt-get install -y -qq certbot python3-certbot-nginx
    certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN
    echo "✅ Domain $DOMAIN configured with SSL"
    ;;
  *)
    echo "🍽️ Restaurant Manager"
    echo "Usage: restaurant <status|restart|logs [nginx|php]|rebuild|backup|domain example.com>"
    ;;
esac
MGMTEOF
chmod +x /usr/local/bin/restaurant
log "تم إنشاء أمر 'restaurant'"

# ════════════════════════════════════════════════════════════
# DONE
# ════════════════════════════════════════════════════════════
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║          ✅ التثبيت اكتمل بنجاح!                ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}🌐 الموقع:${NC}  http://${VPS_IP}"
echo -e "${GREEN}⚙️  الأدمن:${NC} http://${VPS_IP}/admin"
echo -e "${GREEN}🔑 دخول:${NC}   admin@restaurant.com / ${ADMIN_PASS}"
echo -e "${GREEN}🩺 API:${NC}    http://${VPS_IP}/api/health"
echo ""
echo -e "${GREEN}📋 بيانات قاعدة البيانات:${NC}"
echo -e "   DB: restaurant_bot | User: botuser | Pass: ${MYSQL_PASS}"
echo ""
echo -e "${YELLOW}💡 أوامر مفيدة:${NC}"
echo -e "   restaurant status   — حالة الخدمات"
echo -e "   restaurant rebuild  — إعادة بناء الموقع بعد تعديل الكود"
echo -e "   restaurant logs     — اللوجز"
echo -e "   restaurant domain example.com — إضافة دومين + SSL"
echo ""

cat > /root/restaurant-credentials.txt << CREDSEOF
Server IP:     ${VPS_IP}
DB Name:       restaurant_bot
DB User:       botuser
DB Password:   ${MYSQL_PASS}
JWT Secret:    ${JWT_SECRET}
Admin Email:   admin@restaurant.com
Admin Pass:    ${ADMIN_PASS}
Gemini Key:    ${GEMINI_KEY}
Site:          http://${VPS_IP}
Admin Panel:   http://${VPS_IP}/admin
CREDSEOF
chmod 600 /root/restaurant-credentials.txt
echo -e "${YELLOW}💾 البيانات محفوظة في: /root/restaurant-credentials.txt${NC}"
