<?php
// api/customers.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {
    // ─── Get or create customer by WhatsApp ──────────────────────
    case 'POST:get-or-create':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("SELECT c.*, GROUP_CONCAT(ca.label,':', ca.address ORDER BY ca.is_default DESC SEPARATOR '||') as addresses_str FROM customers c LEFT JOIN customer_addresses ca ON c.id=ca.customer_id WHERE c.whatsapp_number=? GROUP BY c.id");
        $stmt->execute([$data['whatsapp_number']]);
        $customer = $stmt->fetch();
        
        if (!$customer) {
            $db->prepare("INSERT INTO customers (whatsapp_number) VALUES (?)")->execute([$data['whatsapp_number']]);
            $customer = ['id' => $db->lastInsertId(), 'whatsapp_number' => $data['whatsapp_number'], 'name' => null, 'is_blacklisted' => 0, 'total_orders' => 0, 'addresses' => []];
        } else {
            $addrs = $db->prepare("SELECT * FROM customer_addresses WHERE customer_id=? ORDER BY is_default DESC");
            $addrs->execute([$customer['id']]);
            $customer['addresses'] = $addrs->fetchAll();
            
            // Get last order
            $lastOrder = $db->prepare("SELECT * FROM orders WHERE customer_id=? ORDER BY created_at DESC LIMIT 1");
            $lastOrder->execute([$customer['id']]);
            $customer['last_order'] = $lastOrder->fetch();
            
            // Get favorite items
            $favs = $db->prepare("SELECT oi.item_name, SUM(oi.quantity) as count FROM order_items oi JOIN orders o ON oi.order_id=o.id WHERE o.customer_id=? GROUP BY oi.item_name ORDER BY count DESC LIMIT 3");
            $favs->execute([$customer['id']]);
            $customer['favorite_items'] = $favs->fetchAll();
        }
        success($customer);

    case 'PUT:update':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $db->prepare("UPDATE customers SET name=?, phone=?, email=? WHERE whatsapp_number=?")
           ->execute([$data['name'], $data['phone']??null, $data['email']??null, $data['whatsapp_number']]);
        success([], 'تم تحديث البيانات');

    case 'POST:add-address':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        // Set default to 0 for others if this is default
        if ($data['is_default'] ?? 0) {
            $db->prepare("UPDATE customer_addresses SET is_default=0 WHERE customer_id=?")->execute([$data['customer_id']]);
        }
        $db->prepare("INSERT INTO customer_addresses (customer_id, label, address, area, zone_id, is_default) VALUES (?,?,?,?,?,?)")
           ->execute([$data['customer_id'], $data['label']??'بيت', $data['address'], $data['area']??null, $data['zone_id']??null, $data['is_default']??0]);
        success(['id' => $db->lastInsertId()], 'تم حفظ العنوان');

    // ─── ADMIN: List customers ────────────────────────────────────
    case 'GET:list':
        requireAuth();
        $db = getDB();
        $search = $_GET['search'] ?? null;
        $sql = "SELECT c.*, COUNT(o.id) as order_count, SUM(o.total_amount) as total_spent FROM customers c LEFT JOIN orders o ON c.id=o.customer_id WHERE 1=1";
        $params = [];
        if ($search) { $sql .= " AND (c.name LIKE ? OR c.whatsapp_number LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
        $sql .= " GROUP BY c.id ORDER BY c.created_at DESC LIMIT 50";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        success($stmt->fetchAll());

    case 'PUT:blacklist':
        requireAuth();
        $id = $path[1] ?? null;
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $db->prepare("UPDATE customers SET is_blacklisted=?, blacklist_reason=? WHERE id=?")
           ->execute([$data['is_blacklisted'], $data['reason']??null, $id]);
        success([], 'تم التحديث');

    default:
        error('Action not found', 404);
}
