<?php
// api/auth.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch("$method:$action") {
    case 'POST:login':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM admin_users WHERE email=? AND is_active=1");
        $stmt->execute([$data['email']]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($data['password'], $user['password'])) error('بيانات غير صحيحة', 401);
        $db->prepare("UPDATE admin_users SET last_login=NOW() WHERE id=?")->execute([$user['id']]);
        $token = generateToken(['id' => $user['id'], 'email' => $user['email'], 'role' => $user['role'], 'branch_id' => $user['branch_id']]);
        success(['token' => $token, 'user' => ['id' => $user['id'], 'name' => $user['name'], 'email' => $user['email'], 'role' => $user['role']]]);

    case 'POST:change-password':
        $auth = requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $user = $db->prepare("SELECT * FROM admin_users WHERE id=?")->execute([$auth['id']]);
        if (!password_verify($data['old_password'], $user['password'])) error('كلمة المرور القديمة غير صحيحة');
        $db->prepare("UPDATE admin_users SET password=? WHERE id=?")->execute([password_hash($data['new_password'], PASSWORD_DEFAULT), $auth['id']]);
        success([], 'تم تغيير كلمة المرور');

    default:
        error('Action not found', 404);
}
