<?php
// api/coupons.php
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_GET['action'] ?? '', '/'));
$action = $path[0] ?? '';

switch("$method:$action") {
    case 'GET:list':
        requireAuth();
        success(getDB()->query("SELECT * FROM coupons ORDER BY created_at DESC")->fetchAll());

    case 'POST:create':
        requireAuth();
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("INSERT INTO coupons (code, description, type, value, min_order_amount, max_discount, usage_limit, usage_per_customer, valid_from, valid_until, is_active) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([strtoupper($data['code']), $data['description']??null, $data['type'], $data['value'], $data['min_order_amount']??0, $data['max_discount']??null, $data['usage_limit']??null, $data['usage_per_customer']??1, $data['valid_from']??null, $data['valid_until']??null, 1]);
        success(['id' => $db->lastInsertId()], 'تم إنشاء الكوبون', 201);

    case 'PUT:toggle':
        requireAuth();
        $id = $path[1] ?? null;
        getDB()->prepare("UPDATE coupons SET is_active = NOT is_active WHERE id=?")->execute([$id]);
        success([], 'تم التحديث');

    case 'DELETE:delete':
        requireAuth();
        $id = $path[1] ?? null;
        getDB()->prepare("DELETE FROM coupons WHERE id=?")->execute([$id]);
        success([], 'تم الحذف');

    case 'POST:validate':
        $data = json_decode(file_get_contents('php://input'), true);
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM coupons WHERE code=? AND is_active=1 AND (valid_from IS NULL OR valid_from<=NOW()) AND (valid_until IS NULL OR valid_until>=NOW()) AND (usage_limit IS NULL OR used_count < usage_limit)");
        $stmt->execute([strtoupper($data['code'])]);
        $coupon = $stmt->fetch();
        if (!$coupon) error('كوبون غير صالح أو منتهي الصلاحية');
        if ($data['subtotal'] < $coupon['min_order_amount']) error("الحد الأدنى للطلب {$coupon['min_order_amount']} جنيه");
        
        // Check customer usage
        $usage = $db->prepare("SELECT COUNT(*) FROM coupon_usage WHERE coupon_id=? AND customer_id=?");
        $usage->execute([$coupon['id'], $data['customer_id']]);
        if ($usage->fetchColumn() >= $coupon['usage_per_customer']) error('لقد استخدمت هذا الكوبون من قبل');
        
        $discount = $coupon['type'] === 'percentage' ? $data['subtotal'] * ($coupon['value']/100) : $coupon['value'];
        if ($coupon['max_discount']) $discount = min($discount, $coupon['max_discount']);
        
        success(['coupon' => $coupon, 'discount' => round($discount, 2)]);

    default:
        error('Action not found', 404);
}
