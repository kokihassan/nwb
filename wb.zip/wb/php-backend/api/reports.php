<?php
// api/reports.php - Sales Reports & Analytics
require_once '../config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

switch ("$method:$action") {

    // ─── Sales report by date range ──────────────────────────
    case 'GET:sales':
        requireAuth();
        $db = getDB();
        $from     = $_GET['from']      ?? date('Y-m-01');
        $to       = $_GET['to']        ?? date('Y-m-d');
        $branchId = $_GET['branch_id'] ?? null;

        $sql    = "WHERE DATE(o.created_at) BETWEEN ? AND ? AND o.status != 'cancelled'";
        $params = [$from, $to];
        if ($branchId) { $sql .= " AND o.branch_id=?"; $params[] = $branchId; }

        // Daily summary
        $daily = $db->prepare("SELECT DATE(o.created_at) as date,
            COUNT(*) as orders,
            SUM(o.total_amount) as revenue,
            SUM(o.delivery_fee) as delivery_income,
            SUM(o.discount_amount) as discounts,
            AVG(o.total_amount) as avg_order
            FROM orders o $sql GROUP BY DATE(o.created_at) ORDER BY date ASC");
        $daily->execute($params);

        // Top items
        $topItems = $db->prepare("SELECT oi.item_name,
            SUM(oi.quantity) as total_qty,
            SUM(oi.total_price) as revenue
            FROM order_items oi JOIN orders o ON oi.order_id=o.id
            $sql GROUP BY oi.item_name ORDER BY total_qty DESC LIMIT 10");
        $topItems->execute($params);

        // Top categories
        $topCats = $db->prepare("SELECT c.name as category,
            SUM(oi.quantity) as total_qty,
            SUM(oi.total_price) as revenue
            FROM order_items oi
            JOIN orders o ON oi.order_id=o.id
            JOIN menu_items mi ON oi.item_id=mi.id
            JOIN categories c ON mi.category_id=c.id
            $sql GROUP BY c.name ORDER BY revenue DESC");
        $topCats->execute($params);

        // Zone performance
        $zones = $db->prepare("SELECT dz.zone_name, b.name as branch,
            COUNT(*) as orders,
            SUM(o.total_amount) as revenue
            FROM orders o
            JOIN delivery_zones dz ON o.zone_id=dz.id
            JOIN branches b ON o.branch_id=b.id
            $sql AND o.order_type='delivery'
            GROUP BY dz.zone_name ORDER BY orders DESC");
        $zones->execute($params);

        // Totals
        $totals = $db->prepare("SELECT
            COUNT(*) as total_orders,
            SUM(total_amount) as total_revenue,
            SUM(delivery_fee) as total_delivery,
            SUM(discount_amount) as total_discounts,
            AVG(total_amount) as avg_order,
            SUM(CASE WHEN order_type='delivery' THEN 1 ELSE 0 END) as delivery_count,
            SUM(CASE WHEN order_type='takeaway' THEN 1 ELSE 0 END) as takeaway_count
            FROM orders o $sql");
        $totals->execute($params);

        // Customer stats
        $customers = $db->prepare("SELECT
            COUNT(DISTINCT customer_id) as unique_customers,
            COUNT(DISTINCT CASE WHEN c.total_orders=1 THEN o.customer_id END) as new_customers
            FROM orders o JOIN customers c ON o.customer_id=c.id $sql");
        $customers->execute($params);

        success([
            'totals'     => $totals->fetch(),
            'customers'  => $customers->fetch(),
            'daily'      => $daily->fetchAll(),
            'top_items'  => $topItems->fetchAll(),
            'top_cats'   => $topCats->fetchAll(),
            'zones'      => $zones->fetchAll(),
            'period'     => ['from' => $from, 'to' => $to],
        ]);

    // ─── Hourly heatmap (best hours) ─────────────────────────
    case 'GET:heatmap':
        requireAuth();
        $db = getDB();
        $days = intval($_GET['days'] ?? 30);

        $stmt = $db->prepare("SELECT
            HOUR(created_at) as hour,
            DAYOFWEEK(created_at) as dow,
            COUNT(*) as orders,
            AVG(total_amount) as avg_value
            FROM orders
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
            AND status != 'cancelled'
            GROUP BY hour, dow ORDER BY dow, hour");
        $stmt->execute([$days]);
        success($stmt->fetchAll());

    // ─── Ratings summary ─────────────────────────────────────
    case 'GET:ratings':
        requireAuth();
        $db = getDB();
        $stmt = $db->query("SELECT
            rating,
            COUNT(*) as count,
            ROUND(COUNT(*)*100.0/(SELECT COUNT(*) FROM orders WHERE rating IS NOT NULL), 1) as pct
            FROM orders WHERE rating IS NOT NULL
            GROUP BY rating ORDER BY rating DESC");
        $ratings = $stmt->fetchAll();

        $avg = $db->query("SELECT AVG(rating) as avg, COUNT(*) as total FROM orders WHERE rating IS NOT NULL")->fetch();
        success(['ratings' => $ratings, 'summary' => $avg]);

    // ─── Export CSV ───────────────────────────────────────────
    case 'GET:export-csv':
        requireAuth();
        $from = $_GET['from'] ?? date('Y-m-01');
        $to   = $_GET['to']   ?? date('Y-m-d');
        $db   = getDB();

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="orders_' . $from . '_' . $to . '.csv"');
        echo "\xEF\xBB\xBF"; // UTF-8 BOM

        $stmt = $db->prepare("SELECT o.order_number, o.created_at, o.status, o.order_type,
            c.name as customer_name, c.whatsapp_number,
            o.delivery_address, dz.zone_name, b.name as branch,
            o.subtotal, o.delivery_fee, o.discount_amount, o.total_amount,
            o.payment_method, o.coupon_code, o.rating
            FROM orders o
            JOIN customers c ON o.customer_id=c.id
            JOIN branches b ON o.branch_id=b.id
            LEFT JOIN delivery_zones dz ON o.zone_id=dz.id
            WHERE DATE(o.created_at) BETWEEN ? AND ?
            ORDER BY o.created_at DESC");
        $stmt->execute([$from, $to]);

        echo "رقم الطلب,التاريخ,الحالة,النوع,اسم العميل,الواتساب,العنوان,المنطقة,الفرع,المجموع,التوصيل,الخصم,الإجمالي,الدفع,الكوبون,التقييم\n";
        while ($row = $stmt->fetch()) {
            echo implode(',', array_map(fn($v) => '"' . str_replace('"', '""', $v ?? '') . '"', array_values($row))) . "\n";
        }
        exit();

    default:
        error('Action not found', 404);
}
